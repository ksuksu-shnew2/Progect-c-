namespace TreasureDungeon;

public class Monster : Charecter
{
     //Health = 30;
    public int Damage {get; set; } =0;
    public TypeMonster typeMonster { get; set; }
     public Random rnd = new();
    


    public void SetStatsByType()
    {
         if (typeMonster == TypeMonster.Goblin)
         {
             Health = rnd.Next(25, 31);
             Damage = rnd.Next(6, 10);
         }
         else if (typeMonster == TypeMonster.Orc)
         {
             Health = rnd.Next(50, 70);
             Damage = rnd.Next(10, 14);
         }
         else if (typeMonster == TypeMonster.Skeleton)
         {
             Health = rnd.Next(35, 45);
             Damage = rnd.Next(12, 18);
         }
         else if (typeMonster == TypeMonster.Boss)
         {
             Health = rnd.Next(100, 200);
             Damage = rnd.Next(18, 30);
         }
         else if (typeMonster == TypeMonster.BossOrc)
         {
             Health = rnd.Next(90, 120);
             Damage = rnd.Next(18, 26);
         }
         
    }
}
